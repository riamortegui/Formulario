using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using RestSharp;
using System.Net.Mime;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IConfiguration _configuration;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [HttpGet("/GetPais")]
        public async Task<IActionResult> Get()
        {
            string Url = _configuration.GetValue<string>("Urls:UrlPais");
            string res = string.Empty;

            using (var client = new RestClient(Url))
            {
                var req = new RestRequest();
                req.AddHeader("Content-Type", "application/json");
                req.Method = Method.Get;
                var resapi = await client.GetAsync(req);
                if (resapi.Content != null)
                {
                    res = resapi.Content;
                }

            }




            return Content(res, MediaTypeNames.Application.Json);

        }
    }
}